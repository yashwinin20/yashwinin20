import { Component, ViewChild, OnInit } from '@angular/core';
import {animate, state, style, transition, trigger} from '@angular/animations';
import { MatTableDataSource, MatSort } from '@angular/material';
import { DataSource } from '@angular/cdk/table';
import { ProjectService } from './projects.service';
import {MatPaginator} from '@angular/material/paginator';
import {merge, Observable, of as observableOf} from 'rxjs';
import {catchError, map, startWith, switchMap} from 'rxjs/operators';

@Component({
  selector: 'app-projects',
  templateUrl: './projects.component.html',
  styleUrls: ['./projects.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({height: '0px', minHeight: '0'})),
      state('expanded', style({height: '*'})),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class ProjectsComponent {
  ELEMENT_DATA: any;
  dataSource;
  resultsLength = 0;
  isLoadingResults = true;
  isRateLimitReached = false;

  @ViewChild(MatPaginator,{static: true}) paginator: MatPaginator;
  @ViewChild(MatSort,{static: true}) sort: MatSort;

  constructor(private service: ProjectService) { }
  ngOnInit() {
    
    this.service.getProjectData().subscribe(items => {
      this.ELEMENT_DATA = items;
      this.dataSource = this.ELEMENT_DATA;
      this.resultsLength = this.dataSource.length;
    }); 
  }

  columnsToDisplay = ['name', 'address', 'status', 'startDate', 'endDate'];
  expandedElement: PeriodicElement | null;
}

export interface PeriodicElement {
  name: string;
  address: string;
  status: boolean;
  contractors: object;
  startDate: string;
  endDate: string;
  
  position: number;
  weight: number;
  symbol: string;
    
}